#include "Text.h"

string Text::get() { return text; }
void Text::append(string _t) { text += _t; }
